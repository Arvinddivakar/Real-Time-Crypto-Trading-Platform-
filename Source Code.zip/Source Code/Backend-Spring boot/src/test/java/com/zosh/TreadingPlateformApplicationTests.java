package com.zosh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreadingPlateformApplicationTests {

	@Test
	void contextLoads() {
	}

}
