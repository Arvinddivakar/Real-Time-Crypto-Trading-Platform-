package com.zosh.request;

import lombok.Data;

@Data
public class PromptBody {
    private String prompt;
}
