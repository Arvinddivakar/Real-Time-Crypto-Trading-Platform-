package com.zosh.domain;

public enum PaymentOrderStatus {
    PENDING,SUCCESS,FAILED
}
